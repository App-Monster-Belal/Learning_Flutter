import 'package:example_app/pages/Add_screen.dart';
import 'package:example_app/pages/home_Page.dart';
import 'package:example_app/pages/my_Ads.dart';
import 'package:flutter/material.dart';

class bottomM extends StatefulWidget {
  @override
  State<bottomM> createState() => _bottomMState();
}

class _bottomMState extends State<bottomM> {
  final pages = [Home(), MyAds(), Add()];

  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: Colors.blue,
          unselectedItemColor: Colors.grey,
          onTap: (val) {

            setState(() {
              _currentIndex = val;
            });
          },
          items: const [
            BottomNavigationBarItem(
                icon: Icon(Icons.home_outlined),
                label: "Home"),
            BottomNavigationBarItem(
                icon: Icon(Icons.shopping_basket_outlined), label: " My Ads"),
            BottomNavigationBarItem(
                icon: Icon(Icons.add_outlined), label: "Add"),
            BottomNavigationBarItem(
                icon: Icon(Icons.message_outlined), label: "Chat"),
            BottomNavigationBarItem(
                icon: Icon(Icons.person_outlined), label: "Account"),
          ]),
      body: pages[_currentIndex],
    );
  }
}
