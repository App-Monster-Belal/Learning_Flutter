import 'package:flutter/material.dart';

class fav extends StatelessWidget {
  const fav({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Card(
            elevation: 4,
            child: ListTile(
              leading: Image.asset(
                "assets/images/watch.png",
                height: 100,
                width: 50,
              ),
              title: const Text(
                "Apple Watch",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
              ),
              subtitle: const Padding(
                padding: EdgeInsets.only(top: 10),
                child: Text(
                  "Series 6. Red",
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w400),
                ),
              ),
              trailing: const Text(
                "\$ 500",
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    color: Colors.blue),
              ),
            ),
          ),
        ),
        Card(
          elevation: 4,
          child: ListTile(
            leading: Image.asset(
              "assets/images/laptop.png",
              height: 100,
              width: 50,
            ),
            title: const Text(
              "Asus Zenbook",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
            ),
            subtitle: const Padding(
              padding: EdgeInsets.only(top: 10),
              child: Text(
                "Model- Zenbook 14 UX425",
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w400),
              ),
            ),
            trailing: const Text(
              "\$ 900",
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  color: Colors.blue),
            ),
          ),
        ),
        Card(
          elevation: 4,
          child: ListTile(
            leading: Image.asset(
              "assets/images/phone.png",
              height: 100,
              width: 50,
            ),
            title: const Text(
              "Samsung Galaxy",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
            ),
            subtitle: const Padding(
              padding: EdgeInsets.only(top: 10),
              child: Text(
                "Model- S22",
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w400),
              ),
            ),
            trailing: const Text(
              "\$ 700",
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  color: Colors.blue),
            ),
          ),
        ),



      ],
    );
  }
}
