import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  List catagories = [
    'Food',
    'Electronics',
    'Groceries',
    'Dress',
    'Technology',
    'Medicine'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 20, left: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Hello Belal.",
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.w600),
              ),
              const Text(
                "Let's Get Something?",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
              ),
              SizedBox(height: 25),
              SizedBox(
                height: 120,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    Container(
                      height: 120,
                      width: 240,
                      decoration: BoxDecoration(
                          color: Colors.deepOrangeAccent,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.only(top: 10, left: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("40% off during\n Covid 19",
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.w500)),
                            Align(
                              alignment: Alignment.bottomRight,
                              child: Image.asset(
                                "assets/images/belal.png",
                                height: 64,
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                      width: 10,
                    ),
                    Container(
                      height: 120,
                      width: 240,
                      decoration: BoxDecoration(
                          color: Colors.deepOrangeAccent,
                          borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: const EdgeInsets.only(top: 10, left: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("40% off during\n Covid 19",
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.w500)),
                            Align(
                              alignment: Alignment.bottomRight,
                              child: Image.asset(
                                "assets/images/belal.png",
                                height: 64,
                              ),
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Top Catagories",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: Text(
                      "View all",
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                          color: Colors.deepOrangeAccent),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 20,
              ),
              SizedBox(
                height: 30,
                child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: catagories.length,
                    itemBuilder: (_, index) {
                      return Padding(
                        padding: const EdgeInsets.only(right: 10),
                        child: Container(
                            decoration: BoxDecoration(
                                color: Colors.grey,
                                borderRadius: BorderRadius.circular(15)),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 3),
                              child: Center(child: Text(catagories[index])),
                            )),
                      );
                    }),
              ),
              SizedBox(
                height: 10,
              ),
              Expanded(child: Padding(
                padding: const EdgeInsets.only(top: 10),
                child: SingleChildScrollView(
                  child: GridView.builder(
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 2,
                      mainAxisSpacing: 20,
                      mainAxisExtent: 250,
                    ),
                    itemCount: 9,
                    itemBuilder: (_, index) {
                      return Expanded(
                          child: Stack(
                            clipBehavior: Clip.none,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(top: 20, left: 15, right: 15),
                                child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      color: Colors.white,
                                      boxShadow: [
                                        BoxShadow(blurRadius: 3.3, color: Colors.grey)
                                      ]),
                                  child: Column(
                                    children: [
                                      SizedBox(
                                          width: 180,
                                          child: Padding(
                                            padding: const EdgeInsets.only(top: 110, left: 25),
                                            child: Text(
                                              "Apple Watch",
                                              style: TextStyle(
                                                  fontSize: 20, fontWeight: FontWeight.w600),
                                            ),

                                          )),
                                      SizedBox(height: 10,),
                                      Text("Series 6. red", style: TextStyle(fontSize: 17, fontWeight: FontWeight.w400),),
                                      SizedBox(height: 15,),
                                      Padding(
                                        padding: const EdgeInsets.only(top: 10, right: 60),
                                        child: Text("\$ 500", style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: Colors.blue),),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Positioned(
                                top: -2,
                                left: 30,
                                child: Container(
                                  child: Image.asset("assets/images/watch.png"),
                                  height: 125,
                                  width: 120,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Colors.pink.shade100,
                                    boxShadow: [
                                      BoxShadow(blurRadius: 2, color: Colors.grey),
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ));
                    },
                  ),
                ),
              ))
            ],
          ),
        ),
      ),
    );
  }
}
