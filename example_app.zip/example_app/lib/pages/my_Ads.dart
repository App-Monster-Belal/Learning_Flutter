import 'package:example_app/ads_page/my_fav.dart';
import 'package:flutter/material.dart';

import '../ads_page/my_ads.dart';

class MyAds extends StatelessWidget {
  final _tabs = [Ads(), fav()];

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      initialIndex: 0,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          automaticallyImplyLeading: false,
          elevation: 5,
          title: Center(
              child: Text(
            "My Ads",
            style: TextStyle(color: Colors.black),
          )),
          bottom: TabBar(
            indicatorColor: Colors.black,
              labelColor: Colors.blue,
              unselectedLabelColor: Colors.black,
              tabs: [
                Tab(
                    text: "My Ads",
                    icon: Icon(
                      Icons.shopping_basket,
                    )),
                Tab(
                  text: "My Favourite ",
                  icon: Icon(Icons.favorite_border_outlined),
                ),


              ]),
        ),

        body: TabBarView(
          children: _tabs,
        ),
      ),
    );

  }
}
