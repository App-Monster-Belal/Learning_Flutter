import 'dart:async';

import 'package:example_app/bottom_nav.dart';
import 'package:flutter/material.dart';

void main()=> runApp( exampleApp());

class exampleApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      debugShowCheckedModeBanner: false,
       home: Splash()
    );
  }
}
class Splash extends StatefulWidget {


  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    Timer(Duration(seconds: 3), () => Navigator.push(context, MaterialPageRoute(builder: (_)=> bottomM(),)));
    super.initState();
  }
  Widget build(BuildContext context) {

    return  Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Text(" Welcome To My First App", style: TextStyle(fontSize: 25, fontWeight: FontWeight.w600),),
              SizedBox(height: 30,),
              CircularProgressIndicator(color: Colors.red,)
            ],
          ),
        ),
      ),
    );
  }
}


